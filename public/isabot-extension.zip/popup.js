// Popup de la extensión: abre la PWA de IsaBot o resume la pestaña actual.
const APP_URL = "https://isa-bot.lovable.app";

document.getElementById("open-app").addEventListener("click", () => {
  chrome.tabs.create({ url: APP_URL });
});

document.getElementById("open-agent").addEventListener("click", () => {
  chrome.tabs.create({ url: APP_URL + "/?agent=1" });
});

document.getElementById("summarize").addEventListener("click", async () => {
  const btn = document.getElementById("summarize");
  const out = document.getElementById("summary-result");
  btn.disabled = true;
  btn.textContent = "🔎 Leyendo…";
  out.style.display = "block";
  out.textContent = "Extrayendo contenido de la pestaña…";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No hay pestaña activa");
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const clone = document.body.cloneNode(true);
        clone.querySelectorAll("script,style,noscript,iframe").forEach((n) => n.remove());
        return (clone.innerText || "").slice(0, 6000);
      },
    });
    const pageText = String(result || "").trim();
    if (!pageText) throw new Error("No pude leer contenido de esta pestaña.");
    btn.textContent = "🧠 Pensando…";
    out.textContent = "IsaBot está resumiendo…";
    const res = await fetch(APP_URL + "/api/agent", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        task:
          "Resume el siguiente contenido de una página web en español, en 5 bullets muy claros y un cierre de una línea. Título: " +
          (tab.title ?? "") +
          "\nURL: " +
          (tab.url ?? "") +
          "\n\nContenido:\n" +
          pageText,
      }),
    });
    if (!res.ok) throw new Error("Error del servidor: " + res.status);
    const data = await res.json();
    out.textContent = data.answer || "IsaBot no devolvió texto.";
  } catch (e) {
    out.textContent = "💔 " + (e && e.message ? e.message : "Error inesperado");
  } finally {
    btn.disabled = false;
    btn.textContent = "Resumir pestaña actual";
  }
});
